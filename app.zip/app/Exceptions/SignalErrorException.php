<?php

namespace App\Exceptions;

use Exception;

class SignalErrorException extends Exception
{
}
