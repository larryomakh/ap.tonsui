<?php

namespace App\Exceptions;

use Exception;

class CopytradeErrorException extends Exception
{
}
