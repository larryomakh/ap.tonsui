<?php

namespace App\Exceptions;

use Exception;

class MembershipException extends Exception
{
    /**
     * Report the exception.
     */
    public function report(): void
    {
        // ...
    }
}
