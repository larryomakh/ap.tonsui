<?php

namespace App\Livewire\Admin\Administrators;

use Livewire\Component;

class ResetPassword extends Component
{
}
